import React from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import {
  FaTicketAlt,
  FaComments,
  FaCheckCircle,
  FaClock,
} from "react-icons/fa";
import styled from "styled-components";
import { IoIosNotifications } from "react-icons/io";
import { RiArrowDropDownLine } from "react-icons/ri";
import { BiUpArrowAlt } from "react-icons/bi";
import { FaArrowDown } from "react-icons/fa6";
import { GoDotFill } from "react-icons/go";

const Header = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 2rem;

  .user-profile {
    display: flex;
    align-items: center;
    margin-right: 20px;
  }

  .user-img {
    width: 25px;
    height: 25px;
    margin-right: 10px;
    border-radius: 50%;
  }
`;

const SummaryCard = styled.div`
  padding: 1rem;
  border-radius: 0.5rem;
  color: #000;
  background-color: transparent;
  box-shadow: 0 0.125rem 0.25rem rgba(0, 0, 0, 0.075);
  display: flex;
  flex-direction: column;
  position: relative;

  .icon {
    position: absolute;
    top: 1rem;
    right: 1rem;
    padding: 10px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
  }

  .icon.red {
    background-color: rgba(255, 0, 0, 0.1);
  }
  .icon.green {
    background-color: rgba(0, 128, 0, 0.1);
  }
  .icon.blue {
    background-color: rgba(0, 0, 255, 0.1);
  }
  .icon.purple {
    background-color: rgba(128, 0, 128, 0.1);
  }

  small {
    font-size: 0.85rem;
  }
`;

const ChatBubble = styled.div`
  background-color: #f8f9fa;
  padding: 1rem;
  border-radius: 0.5rem;
  margin-bottom: 0.5rem;
  display: inline-block;
  max-width: 100%;
  font-size: 14px;

  &.sent {
    background-color: lightblue;
    color: white;
    text-align: right;
    float: right;
    clear: both;
  }

  &.received {
    float: left;
    clear: both;
  }
`;

const ChatProfile = styled.img`
  width: 32px;
  height: 32px;
  border-radius: 50%;
  margin-right: 8px;
`;

function SupportPortal() {
  return (
    <div className="container-fluid bg-light min-vh-100 p-4">
      {/* Header */}
      <Header>
        <h4 style={{ fontSize: "35px", fontWeight: 600 }}>Support Portal</h4>
        <div className="user-profile">
          <IoIosNotifications size={26} />
          <img src="profile.png" alt="User" className="user-img" />
          <h6 style={{ fontSize: "20px", fontWeight: 600 }}>
            Sarah Wilson <RiArrowDropDownLine size={40} />
          </h6>
        </div>
      </Header>

      {/* Top Summary Cards */}
      <div className="row text-dark mb-4">
        <div className="col-md-3 col-sm-6 mb-3">
          <SummaryCard>
            <div className="icon red">
              <FaTicketAlt size={20} color="red" />
            </div>
            <h4 style={{ fontSize: "20px", fontWeight: 600, color: "gray" }}>
              Active Tickets
            </h4>
            <h4 style={{ fontSize: "20px", fontWeight: 650, color: "black" }}>
              42
            </h4>
            <h4 style={{ fontSize: "15px", fontWeight: 650, color: "red" }}>
              {" "}
              <BiUpArrowAlt size={23} /> 8 New Today
            </h4>
          </SummaryCard>
        </div>
        <div className="col-md-3 col-sm-6 mb-3">
          <SummaryCard>
            <div className="icon green">
              <FaComments size={20} color="green" />
            </div>
            <h4 style={{ fontSize: "20px", fontWeight: 600, color: "gray" }}>
              Live Chats
            </h4>
            <h4 style={{ fontSize: "20px", fontWeight: 650, color: "black" }}>
              12
            </h4>
            <h4 style={{ fontSize: "15px", fontWeight: 650, color: "green" }}>
              <GoDotFill size={22} />3 agents active
            </h4>
          </SummaryCard>
        </div>
        <div className="col-md-3 col-sm-6 mb-3">
          <SummaryCard>
            <div className="icon blue">
              <FaCheckCircle size={20} color="blue" />
            </div>
            <h4 style={{ fontSize: "20px", fontWeight: 600, color: "gray" }}>
              Resolved Today
            </h4>
            <h4 style={{ fontSize: "20px", fontWeight: 650, color: "black" }}>
              28
            </h4>
            <h4 style={{ fontSize: "15px", fontWeight: 650, color: "blue" }}>
              <BiUpArrowAlt size={22} />
              85% resolution rate
            </h4>
          </SummaryCard>
        </div>
        <div className="col-md-3 col-sm-6 mb-3">
          <SummaryCard>
            <div className="icon purple">
              <FaClock size={20} color="purple" />
            </div>
            <h4 style={{ fontSize: "20px", fontWeight: 600, color: "gray" }}>
              Average Response Time
            </h4>
            <h4 style={{ fontSize: "20px", fontWeight: 650, color: "black" }}>
              15m
            </h4>
            <h4 style={{ fontSize: "15px", fontWeight: 650, color: "green" }}>
              <FaArrowDown size={20} /> 2m better than target
            </h4>
          </SummaryCard>
        </div>
      </div>

      {/* Main Content */}
      <div className="row">
        {/* Left Column */}
        <div className="col-lg-8">
          {/* Support Tickets */}
          <div className="card mb-4">
            <div className="card-header d-flex justify-content-between align-items-center">
              <h6 className="mb-0">Support Tickets</h6>
              <button className="btn btn-primary btn-sm">New Ticket</button>
            </div>
            <div className="card-body">
              <input
                type="text"
                className="form-control mb-3"
                placeholder="Search tickets..."
              />
              <ul className="list-group">
                <li className="list-group-item d-flex flex-column align-items-start">
                  <div className="d-flex w-100 justify-content-between">
                    <span>
                      {" "}
                      <GoDotFill size={20} color="red" /> Payment Failed -
                      Booking #2458
                    </span>
                    <h6
                      style={{
                        fontSize: "15px",
                        fontWeight: 600,
                        color: "red",
                        backgroundColor: "#f8d7da",
                        padding: "5px",
                        borderRadius: "10px",
                      }}
                    >
                      High
                    </h6>
                  </div>
                  <small className="text-muted mt-1">Updated 5 mins ago</small>
                </li>
                <li className="list-group-item d-flex flex-column align-items-start">
                  <div className="d-flex w-100 justify-content-between">
                    <span>
                      {" "}
                      <GoDotFill size={20} color="orange" /> Driver Late - Trip
                      #8547
                    </span>
                    <h6
                      style={{
                        fontSize: "15px",
                        fontWeight: 600,
                        color: "orange",
                        backgroundColor: "#fff3cd",
                        padding: "5px",
                        borderRadius: "10px",
                      }}
                    >
                      Medium
                    </h6>
                  </div>
                  <small className="text-muted mt-1">Updated 12 mins ago</small>
                </li>
                <li className="list-group-item d-flex flex-column align-items-start">
                  <div className="d-flex w-100 justify-content-between">
                    <span>
                      {" "}
                      <GoDotFill size={20} color="green" /> App Login Issue -
                      User #1247
                    </span>
                    <h6
                      style={{
                        fontSize: "15px",
                        fontWeight: 600,
                        color: "green",
                        backgroundColor: "#d4edda",
                        padding: "5px",
                        borderRadius: "10px",
                      }}
                    >
                      Low
                    </h6>
                  </div>
                  <small className="text-muted mt-1">Updated 25 mins ago</small>
                </li>
              </ul>
            </div>
          </div>

          {/* ✅ Recent Feedback (Responsive) */}
          <div className="card mb-4 w-100" style={{ height: "auto" }}>
            <div className="card-header">
              <h6 className="mb-0">Recent Feedback</h6>
            </div>
            <div className="card-body">
              <div className="mb-3">
                <div className="d-flex justify-content-between">
                  <span>⭐⭐⭐⭐☆ Trip #4521</span>
                  <small className="text-muted">2 hours ago</small>
                </div>
                <p className="mb-0">
                  Great service, but the driver was slightly late.
                </p>
              </div>
              <div>
                <div className="d-flex justify-content-between">
                  <span>⭐⭐⭐⭐⭐ Trip #4520</span>
                  <small className="text-muted">3 hours ago</small>
                </div>
                <p className="mb-0">
                  Excellent experience! Very professional driver.
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Right Column */}
        <div className="col-lg-4">
          {/* Live Chat */}
          <div className="card mb-4">
            <div className="card-header">
              <h6 className="mb-0">Live Chat</h6>
            </div>
            <div
              className="card-body"
              style={{ maxHeight: "300px", overflowY: "auto" }}
            >
              <div className="mb-3 d-flex align-items-start">
                <ChatProfile src="boy.png" alt="Boy" />
                <ChatBubble className="received">
                  <div
                    style={{
                      color: "black",
                      fontWeight: "450",
                      backgroundColor: "whitesmoke",
                    }}
                  >
                    Hi, I’m having trouble with my booking
                  </div>
                  <small>10:24 AM</small>
                </ChatBubble>
              </div>
              <div className="mb-3 d-flex justify-content-end align-items-start">
                <ChatBubble className="sent">
                  <h6 style={{ color: "black", fontWeight: "450" }}>
                    Hello! I’d be happy to help. Could you please provide your
                    booking number?
                  </h6>
                  <h7 style={{ color: "black", fontWeight: "450" }}>
                    10:25 AM
                  </h7>
                </ChatBubble>
                <ChatProfile src="girl.png" alt="Girl" />
              </div>
              <input
                className="form-control mt-3"
                placeholder="Type your message..."
              />
            </div>
          </div>

          {/* ✅ Payment Issues (Responsive) */}
          <div className="card w-100" style={{ height: "auto" }}>
            <div className="card-header">
              <h6 className="mb-0">Payment Issues</h6>
            </div>
            <div className="card-body text-muted">
              {/* Placeholder content */}
              <p>No payment issues reported today.</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default SupportPortal;
