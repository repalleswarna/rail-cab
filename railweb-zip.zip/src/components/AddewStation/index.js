import React, { useState } from "react";
import styled from "styled-components";
import "bootstrap/dist/css/bootstrap.min.css";
import { Form, Button } from "react-bootstrap";

const Container = styled.div`
  background: #fff;
  padding: 2rem;
  border-radius: 10px;
  max-width: 800px;
  margin: 2rem auto;
  box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
`;

const ScrollableForm = styled.div`
  max-height: 500px;
  overflow-y: auto;
  padding-right: 0.5rem;
`;

const Title = styled.h5`
  font-weight: 640;
  margin-bottom: 1.5rem;
  font-size: 1.6rem;
`;

const StyledButton = styled(Button)`
  padding: 0.5rem 1.5rem;
  font-weight: 900;
  border-radius: 5px;
`;

const ToggleWrapper = styled.div`
  display: flex;
  align-items: center;
  gap: 0.5rem;
`;

const TextArea = styled.textarea`
  width: 100%;
  height: 60px;
  border-radius: 5px;
  border: 1px solid #ccc;
  padding: 0.5rem;
`;

const RedAsterisk = styled.span`
  color: red;
`;

const BluePlusButton = styled.button`
  color: blue !important;
  border-color: #6c757d;
  background-color: transparent;
`;

function AddNewStation() {
  const [formData, setFormData] = useState({
    stationName: "",
    city: "",
    pickupPoint: "",
    locationDetails: "",
    category: "",
    platforms: "",
    openingTime: "",
    closingTime: "",
    contactNumber: "",
    manager: "",
    isActive: true,
    notes: "",
  });

  const [errors, setErrors] = useState({});

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: type === "checkbox" ? checked : value,
    }));

    // Clear error as user types
    setErrors((prev) => ({ ...prev, [name]: "" }));
  };

  const validate = () => {
    const newErrors = {};
    const requiredFields = [
      "stationName",
      "city",
      "pickupPoint",
      "locationDetails",
      "category",
      "platforms",
      "openingTime",
      "closingTime",
      "contactNumber",
      "manager",
    ];

    requiredFields.forEach((field) => {
      if (!formData[field]) {
        newErrors[field] = "Required";
      }
    });

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSave = (e) => {
    e.preventDefault();
    if (validate()) {
      alert("Station saved successfully!");
      // Proceed with API call or form submission
    }
  };

  return (
    <Container>
      <div className="d-flex justify-content-between align-items-center mb-3">
        <Title>Add New Station</Title>
        <button className="btn-close" aria-label="Close"></button>
      </div>

      <hr />

      <Form onSubmit={handleSave}>
        <ScrollableForm>
          <div className="row g-3">
            <div className="col-md-6">
              <Form.Group>
                <Form.Label>
                  Station Name <RedAsterisk>*</RedAsterisk>
                </Form.Label>
                <Form.Control
                  type="text"
                  name="stationName"
                  value={formData.stationName}
                  onChange={handleChange}
                  placeholder="Enter Station Name"
                  className={errors.stationName ? "is-invalid" : ""}
                />
              </Form.Group>
            </div>

            <div className="col-md-6">
              <Form.Group>
                <Form.Label>
                  City <RedAsterisk>*</RedAsterisk>
                </Form.Label>
                <Form.Select
                  name="city"
                  value={formData.city}
                  onChange={handleChange}
                  className={errors.city ? "is-invalid" : ""}
                >
                  <option value="">Select City</option>
                  <option value="City A">City A</option>
                </Form.Select>
              </Form.Group>
            </div>

            <div className="col-md-6">
              <Form.Group>
                <Form.Label>
                  Pickup Points <RedAsterisk>*</RedAsterisk>
                </Form.Label>
                <Form.Control
                  type="text"
                  name="pickupPoint"
                  value={formData.pickupPoint}
                  onChange={handleChange}
                  placeholder="Point Name"
                  className={errors.pickupPoint ? "is-invalid" : ""}
                />
              </Form.Group>
            </div>

            <div className="col-md-5">
              <Form.Group>
                <Form.Label>&nbsp;</Form.Label>
                <Form.Control
                  type="text"
                  name="locationDetails"
                  value={formData.locationDetails}
                  onChange={handleChange}
                  placeholder="Location Details"
                  className={errors.locationDetails ? "is-invalid" : ""}
                />
              </Form.Group>
            </div>

            <div className="col-md-1 d-flex align-items-end">
              <BluePlusButton
                type="button"
                className="btn btn-outline-secondary w-100"
              >
                +
              </BluePlusButton>
            </div>

            <div className="col-md-6">
              <Form.Group>
                <Form.Label>
                  Station Category <RedAsterisk>*</RedAsterisk>
                </Form.Label>
                <Form.Select
                  name="category"
                  value={formData.category}
                  onChange={handleChange}
                  className={errors.category ? "is-invalid" : ""}
                >
                  <option value="">Select Category</option>
                  <option value="Category A">Category A</option>
                </Form.Select>
              </Form.Group>
            </div>

            <div className="col-md-6">
              <Form.Group>
                <Form.Label>
                  Number of Platforms <RedAsterisk>*</RedAsterisk>
                </Form.Label>
                <Form.Control
                  type="number"
                  name="platforms"
                  value={formData.platforms}
                  onChange={handleChange}
                  placeholder="Enter number"
                  className={errors.platforms ? "is-invalid" : ""}
                />
              </Form.Group>
            </div>

            <div className="col-md-6">
              <Form.Group>
                <Form.Label>
                  Opening Time <RedAsterisk>*</RedAsterisk>
                </Form.Label>
                <Form.Control
                  type="time"
                  name="openingTime"
                  value={formData.openingTime}
                  onChange={handleChange}
                  className={errors.openingTime ? "is-invalid" : ""}
                />
              </Form.Group>
            </div>

            <div className="col-md-6">
              <Form.Group>
                <Form.Label>
                  Closing Time <RedAsterisk>*</RedAsterisk>
                </Form.Label>
                <Form.Control
                  type="time"
                  name="closingTime"
                  value={formData.closingTime}
                  onChange={handleChange}
                  className={errors.closingTime ? "is-invalid" : ""}
                />
              </Form.Group>
            </div>

            <div className="col-md-6">
              <Form.Group>
                <Form.Label>
                  Station Contact Number <RedAsterisk>*</RedAsterisk>
                </Form.Label>
                <Form.Control
                  type="text"
                  name="contactNumber"
                  value={formData.contactNumber}
                  onChange={handleChange}
                  placeholder="Enter number"
                  className={errors.contactNumber ? "is-invalid" : ""}
                />
              </Form.Group>
            </div>

            <div className="col-md-6">
              <Form.Group>
                <Form.Label>
                  Station Manager <RedAsterisk>*</RedAsterisk>
                </Form.Label>
                <Form.Control
                  type="text"
                  name="manager"
                  value={formData.manager}
                  onChange={handleChange}
                  placeholder="Manager Name"
                  className={errors.manager ? "is-invalid" : ""}
                />
              </Form.Group>
            </div>

            <div className="col-md-12">
              <ToggleWrapper className="form-check form-switch">
                <input
                  className="form-check-input"
                  type="checkbox"
                  role="switch"
                  id="activeToggle"
                  name="isActive"
                  checked={formData.isActive}
                  onChange={handleChange}
                />
                <label className="form-check-label" htmlFor="activeToggle">
                  Station Active
                </label>
              </ToggleWrapper>
            </div>

            <div className="col-md-12">
              <Form.Group>
                <Form.Label>Additional Notes</Form.Label>
                <TextArea
                  name="notes"
                  value={formData.notes}
                  onChange={handleChange}
                />
              </Form.Group>
            </div>
          </div>
        </ScrollableForm>

        <hr />

        <div className="col-md-12 d-flex justify-content-end gap-2 mt-3">
          <Button variant="light">Cancel</Button>
          <StyledButton type="submit" variant="primary">
            Save Station
          </StyledButton>
        </div>
      </Form>
    </Container>
  );
}

export default AddNewStation;
