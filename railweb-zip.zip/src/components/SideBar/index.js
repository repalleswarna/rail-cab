import React, { useState } from "react";
import styled from "styled-components";
import "bootstrap/dist/css/bootstrap.min.css";
import {
  FaTachometerAlt,
  FaBusAlt,
  FaFileInvoice,
  FaUsersCog,
  FaHeadset,
  FaBell,
  FaCogs,
} from "react-icons/fa";
import { MdOutlineLibraryBooks } from "react-icons/md";
import Dashboard from "../Dashboard";
import NotificationPanel from "../NotificationPanel";
import SettingsPanel from "../SettingsPanel";
import ServiceManager from "../ServiceManager";
import Accountant from "../Accountant";
import HRModule from "../HRModule";
import SupportPortal from "../SupportPortal";
import ContentManagement from "../ContentManagement";

const SideBar = () => {
  const [activeTab, setActiveTab] = useState("Dashboard");

  const renderContent = () => {
    switch (activeTab) {
      case "Dashboard":
        return <Dashboard />;
      case "Service Manager":
        return <ServiceManager />;
      case "Accountant":
        return <Accountant />;
      case "HR Module":
        return <HRModule />;
      case "Support Module":
        return <SupportPortal />;
      case "CMS":
        return <ContentManagement />;
      case "Notifications":
        return <NotificationPanel />;
      case "Settings":
        return <SettingsPanel />;
      default:
        return <Dashboard />;
    }
  };

  return (
    <Container>
      <Sidebar>
        <Brand>RailCab Admin</Brand>
        <NavItem
          active={activeTab === "Dashboard"}
          onClick={() => setActiveTab("Dashboard")}
        >
          <FaTachometerAlt size={20} className="icon" />
          <NavText>Dashboard</NavText>
        </NavItem>
        <NavItem
          active={activeTab === "Service Manager"}
          onClick={() => setActiveTab("Service Manager")}
        >
          <FaBusAlt size={19} className="icon" />
          <NavText>Service Manager</NavText>
        </NavItem>
        <NavItem
          active={activeTab === "Accountant"}
          onClick={() => setActiveTab("Accountant")}
        >
          <FaFileInvoice size={20} className="icon" />
          <NavText>Accountant</NavText>
        </NavItem>
        <NavItem
          active={activeTab === "HR Module"}
          onClick={() => setActiveTab("HR Module")}
        >
          <FaUsersCog size={24} className="icon" />
          <NavText>HR Module</NavText>
        </NavItem>
        <NavItem
          active={activeTab === "Support Module"}
          onClick={() => setActiveTab("Support Module")}
        >
          <FaHeadset size={20} className="icon" />
          <NavText>Support Module</NavText>
        </NavItem>
        <NavItem
          active={activeTab === "CMS"}
          onClick={() => setActiveTab("CMS")}
        >
          <MdOutlineLibraryBooks size={22} className="icon" />
          <NavText>CMS</NavText>
        </NavItem>
        <NavItem
          active={activeTab === "Notifications"}
          onClick={() => setActiveTab("Notifications")}
        >
          <FaBell size={20} className="icon" />
          <NavText>Notifications</NavText>
        </NavItem>
        <NavItem
          active={activeTab === "Settings"}
          onClick={() => setActiveTab("Settings")}
        >
          <FaCogs size={20} className="icon" />
          <NavText>Settings</NavText>
        </NavItem>
      </Sidebar>
      {renderContent()}
    </Container>
  );
};

export default SideBar;

// Styled Components
const Container = styled.div`
  display: flex;
  height: 100vh;
  background: #f8f9fa;
`;

const Sidebar = styled.div`
  width: 250px;
  background-color: #fff;
  border-right: 1px solid #dee2e6;
  padding: 20px 0;
  display: flex;
  flex-direction: column;

  @media (max-width: 768px) {
    width: 100%;
    height: auto;
  }
`;

const Brand = styled.h5`
  font-weight: 600;
  color: #007bff;
  padding: 0 20px;
  margin-bottom: 20px;
`;

const NavItem = styled.div`
  display: flex;
  align-items: center;
  padding: 12px 20px;
  color: ${(props) => (props.active ? "#007bff" : "#343a40")};
  background-color: ${(props) => (props.active ? "#e9f3ff" : "transparent")};
  cursor: pointer;
  font-size: 15px;
  transition: background 0.3s;

  .icon {
    margin-right: 12px;
  }

  &:hover {
    background-color: #f1f1f1;
  }
`;

const NavText = styled.span`
  font-size: 16px;
  color: gray;
`;
