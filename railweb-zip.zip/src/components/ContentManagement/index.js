import React from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import styled from "styled-components";
import {
  BsCheckCircleFill,
  BsCalendar,
  BsFileEarmarkText,
  BsPlus,
} from "react-icons/bs";
import { IoIosNotifications } from "react-icons/io";
import { FaAngleDown } from "react-icons/fa";
import { BsPencilSquare } from "react-icons/bs";
import { MdDelete } from "react-icons/md";
import { RiDownloadCloudFill } from "react-icons/ri";
import { RiPencilFill } from "react-icons/ri";
import { IoImageSharp } from "react-icons/io5";

// Styled Components
const SectionBox = styled.div`
  background: #fff;
  border-radius: 10px;
  padding: 20px;
  box-shadow: 0 0 4px rgba(57, 23, 23, 0.05);
  height: 100%;
`;

const IconButton = styled.button`
  background: none;
  border: none;
  padding: 0 5px;
  color: #333;
  &:hover {
    opacity: 0.8;
  }
`;

const UploadBox = styled.div`
  border: 2px dashed #d9d9d9;
  border-radius: 10px;
  text-align: center;
  padding: 20px;
  color: #999;
  font-size: 14px;
`;

const ActivityItem = styled.div`
  display: flex;
  align-items: flex-start;
  gap: 10px;
  margin-bottom: 10px;
  font-size: 14px;
`;

const IconWrapper = styled.div`
  background-color: ${({ bg }) => bg || "#f0f0f0"};
  border-radius: 50%;
  padding: 8px;
  display: flex;
  align-items: center;
  justify-content: center;
`;

const ContentManagement = () => {
  return (
    <div className="container-fluid bg-light min-vh-100 p-4">
      {/* Header */}
      <div className="d-flex justify-content-between align-items-center mb-4">
        <h5
          style={{ fontSize: "22px", fontWeight: 750 }}
          className="fw-semibold"
        >
          Content Management
        </h5>
        <div className="d-flex align-items-center gap-2">
          <IoIosNotifications size={20} />
          <img
            src="profile.png"
            alt="avatar"
            className="rounded-circle"
            width={24}
            height={24}
          />
          <span className="fw-semibold"> John Smith</span>
          <FaAngleDown />
        </div>
      </div>
      <hr
        style={{
          borderTop: "1px solid #999",
          marginTop: "0",
          marginBottom: "1rem",
        }}
      />

      {/* Main Grid */}
      <div className="row g-3 mb-4">
        {/* FAQs */}
        <div className="col-lg-4">
          <SectionBox>
            <div className="d-flex justify-content-between align-items-center mb-3">
              <h6 className="fw-bold">FAQs</h6>
              <button className="btn btn-primary btn-sm">Add FAQ</button>
            </div>
            <hr
              style={{
                borderTop: "1px solid #999",
                marginTop: "0",
                marginBottom: "1rem",
              }}
            />

            <div className="border p-2 rounded mb-3">
              <div className="d-flex justify-content-between align-items-center">
                <strong>Booking & Payments</strong>
                <div className="text-muted small">12 entries</div>
              </div>
              <div className="d-flex gap-2 mt-2">
                <IconButton>
                  <BsPencilSquare color="blue" />
                </IconButton>
                <IconButton>
                  <MdDelete color="red" size={20} />
                </IconButton>
              </div>
            </div>

            <div className="border p-2 rounded">
              <div className="d-flex justify-content-between align-items-center">
                <strong>Service & Support</strong>
                <div className="text-muted small">8 entries</div>
              </div>
              <div className="d-flex gap-2 mt-2">
                <IconButton>
                  <BsPencilSquare color="blue" />
                </IconButton>
                <IconButton>
                  <MdDelete color="red" size={20} />
                </IconButton>
              </div>
            </div>
          </SectionBox>
        </div>

        {/* Legal Pages */}
        <div className="col-lg-4">
          <SectionBox>
            <div className="d-flex justify-content-between align-items-center mb-3">
              <h6 className="fw-bold">Legal Pages</h6>
              <button className="btn btn-primary btn-sm">Add Page</button>
            </div>
            <hr
              style={{
                borderTop: "1px solid #999",
                marginTop: "0",
                marginBottom: "1rem",
              }}
            />

            <div className="d-flex align-items-center justify-content-between border p-2 rounded mb-2">
              <span className="d-flex align-items-center">
                <BsFileEarmarkText className="me-2" />
                Terms & Conditions
              </span>
              <IconButton>
                <BsPencilSquare color="blue" />
              </IconButton>
            </div>
            <div className="d-flex align-items-center justify-content-between border p-2 rounded">
              <span className="d-flex align-items-center">
                <BsFileEarmarkText className="me-2" />
                Privacy Policy
              </span>
              <IconButton>
                <BsPencilSquare color="blue" />
              </IconButton>
            </div>
          </SectionBox>
        </div>

        {/* Media & Events */}
        <div className="col-lg-4">
          <SectionBox>
            <div className="d-flex justify-content-between align-items-center mb-3">
              <h6 className="fw-bold">Media & Events</h6>
              <button className="btn btn-primary btn-sm">Upload Media</button>
            </div>
            <hr
              style={{
                borderTop: "1px solid #999",
                marginTop: "0",
                marginBottom: "1rem",
              }}
            />

            <div className="border rounded p-2 mb-2">
              <div className="d-flex justify-content-between">
                <strong>Summer Campaign 2025</strong>
                <span className="badge bg-success d-flex align-items-center gap-1">
                  <BsCheckCircleFill size={14} /> Active
                </span>
              </div>
              <div className="text-muted small d-flex align-items-center mt-1">
                <BsCalendar
                  style={{ fontSize: "15px", fontWeight: "1200" }}
                  className="me-2"
                />
                May 15, 2025
              </div>
              <div className="d-flex justify-content-end gap-2 mt-2">
                <IconButton>
                  <BsPencilSquare color="blue" />
                </IconButton>
                <IconButton>
                  <MdDelete color="red" size={20} />
                </IconButton>
              </div>
            </div>
            <UploadBox>
              <RiDownloadCloudFill size={35} />
              <div
                style={{ fontSize: "15px", fontWeight: "600", color: "black" }}
              >
                Drag and drop media files here
              </div>
              <h1
                style={{ fontSize: "12px", fontWeight: "600", color: "gray" }}
              >
                Supports: JPG, PNG, MP4 (max 10MB)
              </h1>
            </UploadBox>
          </SectionBox>
        </div>
      </div>

      {/* Recent Activity */}
      <SectionBox>
        <h6 className="fw-bold mb-3">Recent Activity</h6>
        <hr
          style={{
            borderTop: "1px solid #999",
            marginTop: "0",
            marginBottom: "1rem",
          }}
        />

        <ActivityItem>
          <IconWrapper bg="#e0f0ff">
            <RiPencilFill size={20} color="blue" />
          </IconWrapper>
          <div>
            <div>
              <strong>Terms & Conditions page updated</strong>
            </div>
            <div className="text-muted small">2 hours ago by Admin</div>
          </div>
        </ActivityItem>

        <ActivityItem>
          <IconWrapper bg="#d9f9e2">
            <BsPlus size={20} className="text-success" />
          </IconWrapper>
          <div>
            <div>
              <strong>New FAQ category added: Refunds</strong>
            </div>
            <div className="text-muted small">4 hours ago by Support Team</div>
          </div>
        </ActivityItem>

        <ActivityItem>
          <IconWrapper bg="#ece1fc">
            <IoImageSharp size={20} color="purple" />
          </IconWrapper>
          <div>
            <div>
              <strong>New event banner uploaded</strong>
            </div>
            <div className="text-muted small">Yesterday by Marketing</div>
          </div>
        </ActivityItem>
      </SectionBox>
    </div>
  );
};

export default ContentManagement;
