// src/SettingsPanel.js
import React from "react";
import styled from "styled-components";
import { FaUserShield, FaTools, FaCalculator, FaUsers } from "react-icons/fa";

const SettingsContainer = styled.div`
  background-color: #f8f9fc;
  min-height: 100vh;
  font-family: "Segoe UI", sans-serif;
  width: 100%;
`;

const ContentContainer = styled.div`
  max-width: 1300px;
  margin: 0 auto;
  padding: 20px;
`;

const Header = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 30px;
  flex-direction: column;
  gap: 20px;

  @media (min-width: 768px) {
    flex-direction: row;
  }
`;

const HeaderLeft = styled.div`
  display: flex;
  align-items: center;
  gap: 20px;
  order: 1;

  @media (min-width: 768px) {
    order: 0;
  }
`;

const HeaderRight = styled.div`
  display: flex;
  align-items: center;
  gap: 20px;
  order: 0;

  @media (min-width: 768px) {
    order: 1;
  }
`;

const Profile = styled.div`
  display: flex;
  align-items: center;
  gap: 10px;
`;

const ProfileImage = styled.img`
  width: 32px;
  height: 32px;
  border-radius: 50%;
  object-fit: cover;
`;

const ProfileName = styled.span`
  color: #0f172a;
  font-weight: 500;
`;

const Title = styled.h1`
  font-weight: 600;
  margin-bottom: 10px;
  color: #212529;
`;

const Description = styled.p`
  color: #6c757d;
  margin-top: -8px;
`;

const MainContent = styled.div`
  display: flex;
  flex-direction: column;
  gap: 30px;
  @media (min-width: 992px) {
    flex-direction: row;
  }
`;

const Sidebar = styled.div`
  width: 100%;
  background-color: #fff;
  padding: 20px;
  border-radius: 8px;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.05);
  @media (min-width: 992px) {
    width: 280px;
  }
`;

const Content = styled.div`
  flex: 1;
  background-color: #fff;
  padding: 25px;
  border-radius: 8px;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.05);
`;

const SearchBox = styled.input`
  width: 100%;
  padding: 10px;
  border: 1px solid #ced4da;
  border-radius: 6px;
  margin-bottom: 20px;
`;

const SectionTitle = styled.h5`
  margin-top: 20px;
  color: #6c757d;
  font-size: 15px;
  font-weight: 600;
`;

const RoleButton = styled.div`
  display: flex;
  align-items: center;
  padding: 10px;
  border-radius: 6px;
  cursor: pointer;
  color: ${(props) => (props.active ? "#0d6efd" : "#212529")};
  background-color: ${(props) => (props.active ? "#e7f1ff" : "transparent")};
  font-weight: ${(props) => (props.active ? "600" : "400")};
  margin-bottom: 10px;
`;

const Avatar = styled.img`
  width: 32px;
  height: 32px;
  border-radius: 50%;
  margin-right: 10px;
`;

const ButtonHeaderContainer = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: flex-start;
  flex-direction: column;
  margin-bottom: 20px;

  @media (min-width: 768px) {
    flex-direction: row;
    align-items: center;
  }
`;

const TitleGroup = styled.div`
  margin-bottom: 10px;

  @media (min-width: 768px) {
    margin-bottom: 0;
  }
`;

const ButtonGroup = styled.div`
  display: flex;
  gap: 10px;
  margin-top: 15px;

  @media (min-width: 768px) {
    margin-top: 0;
  }
`;

const Button = styled.button`
  padding: 8px 16px;
  border-radius: 6px;
  font-weight: 500;
  cursor: pointer;
  border: 1px solid transparent;

  &.outline {
    background-color: transparent;
    border-color: #6c757d;
    color: #6c757d;
  }

  &.primary {
    background-color: #0d6efd;
    color: white;
  }
`;

const PermissionSection = styled.div`
  margin-top: 25px;
`;

const SectionHeader = styled.h3`
  font-weight: 600;
  margin-bottom: 20px;
  color: #212529;
`;

const PermissionGrid = styled.div`
  display: grid;
  grid-template-columns: 1fr;
  gap: 20px;
  @media (min-width: 768px) {
    grid-template-columns: 1fr 1fr;
  }
`;

const PermissionItem = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 15px 0;
  border-bottom: 1px solid #e9ecef;
`;

const PermissionInfo = styled.div``;

const PermissionLabel = styled.div`
  font-weight: 500;
  margin-bottom: 5px;
`;

const PermissionDescription = styled.div`
  color: #6c757d;
  font-size: 14px;
`;

const Toggle = styled.input.attrs({ type: "checkbox" })`
  appearance: none;
  width: 36px;
  height: 20px;
  background: #dee2e6;
  border-radius: 10px;
  position: relative;
  outline: none;
  cursor: pointer;

  &:checked {
    background: #0d6efd;
  }

  &:checked::before {
    left: 18px;
  }

  &::before {
    content: "";
    position: absolute;
    top: 2px;
    left: 2px;
    background: white;
    width: 16px;
    height: 16px;
    border-radius: 50%;
    transition: 0.3s;
  }
`;

const SettingsPanel = () => {
  return (
    <SettingsContainer>
      <ContentContainer>
        <Header>
          <HeaderLeft>
            <Title>Notification Permissions</Title>
          </HeaderLeft>
          <HeaderRight>
            <Profile>
              <ProfileImage
                src="https://randomuser.me/api/portraits/men/32.jpg"
                alt="John Smith"
              />
              <ProfileName>John Smith</ProfileName>
            </Profile>
          </HeaderRight>
        </Header>

        <MainContent>
          <Sidebar>
            <SearchBox placeholder="Search roles or users..." />
            <SectionTitle>Roles</SectionTitle>
            <RoleButton active>
              <FaUserShield className="me-2" /> Super Admin
            </RoleButton>
            <RoleButton>
              <FaTools className="me-2" /> Service Manager
            </RoleButton>
            <RoleButton>
              <FaCalculator className="me-2" /> Accountant
            </RoleButton>
            <RoleButton>
              <FaUsers className="me-2" /> HR Manager
            </RoleButton>

            <SectionTitle>Individual Users</SectionTitle>
            <RoleButton>
              <Avatar src="https://randomuser.me/api/portraits/men/32.jpg" />{" "}
              Mike Johnson
            </RoleButton>
            <RoleButton>
              <Avatar src="https://randomuser.me/api/portraits/women/44.jpg" />{" "}
              Sarah Wilson
            </RoleButton>
          </Sidebar>

          <Content>
            <ButtonHeaderContainer>
              <TitleGroup>
                <h2>Super Admin Permissions</h2>
                <Description>
                  Configure notification permissions for this role
                </Description>
              </TitleGroup>
              <ButtonGroup>
                <Button className="outline">Reset to Default</Button>
                <Button className="primary">Save Changes</Button>
              </ButtonGroup>
            </ButtonHeaderContainer>

            <PermissionSection>
              <SectionHeader>Notification Capabilities</SectionHeader>
              <PermissionGrid>
                <PermissionItem>
                  <PermissionInfo>
                    <PermissionLabel>Send Push Notifications</PermissionLabel>
                    <PermissionDescription>
                      Send real-time push notifications to users
                    </PermissionDescription>
                  </PermissionInfo>
                  <Toggle defaultChecked />
                </PermissionItem>

                <PermissionItem>
                  <PermissionInfo>
                    <PermissionLabel>Schedule Notifications</PermissionLabel>
                    <PermissionDescription>
                      Schedule notifications for future delivery
                    </PermissionDescription>
                  </PermissionInfo>
                  <Toggle defaultChecked />
                </PermissionItem>

                <PermissionItem>
                  <PermissionInfo>
                    <PermissionLabel>Send Emails</PermissionLabel>
                    <PermissionDescription>
                      Send email notifications to users
                    </PermissionDescription>
                  </PermissionInfo>
                  <Toggle defaultChecked />
                </PermissionItem>

                <PermissionItem>
                  <PermissionInfo>
                    <PermissionLabel>View Notification Logs</PermissionLabel>
                    <PermissionDescription>
                      Access notification history and logs
                    </PermissionDescription>
                  </PermissionInfo>
                  <Toggle defaultChecked />
                </PermissionItem>

                <PermissionItem>
                  <PermissionInfo>
                    <PermissionLabel>Send SMS</PermissionLabel>
                    <PermissionDescription>
                      Send SMS notifications to users
                    </PermissionDescription>
                  </PermissionInfo>
                  <Toggle defaultChecked />
                </PermissionItem>

                <PermissionItem>
                  <PermissionInfo>
                    <PermissionLabel>Manage Templates</PermissionLabel>
                    <PermissionDescription>
                      Create and edit notification templates
                    </PermissionDescription>
                  </PermissionInfo>
                  <Toggle defaultChecked />
                </PermissionItem>
              </PermissionGrid>
            </PermissionSection>
          </Content>
        </MainContent>
      </ContentContainer>
    </SettingsContainer>
  );
};

export default SettingsPanel;
