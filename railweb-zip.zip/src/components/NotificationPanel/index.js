import React from "react";
import styled from "styled-components";
import { FaBell, FaEllipsisV, FaChevronDown } from "react-icons/fa";
import "bootstrap/dist/css/bootstrap.min.css";

const NotificationPanel = () => {
  return (
    <Wrapper>
      <div className="container py-4">
        {/* Header Section */}
        <Header className="d-flex justify-content-between align-items-center flex-wrap mb-4">
          <h4 className="mb-2 mb-md-0 fw-bold">Notifications Manager</h4>
          <div className="d-flex align-items-center gap-3 flex-wrap">
            <FaBell className="text-muted fs-5" />
            <UserDropdown className="d-flex align-items-center">
              <img
                src="https://randomuser.me/api/portraits/men/32.jpg"
                alt="John Smith"
                style={{ width: "32px", height: "32px", borderRadius: "50%" }}
              />
              <UserName className="ms-2">John Smith</UserName>
              <FaChevronDown className="ms-1 text-muted" />
            </UserDropdown>
          </div>
        </Header>

        {/* Create Notification */}
        <Card className="mb-4 p-4 shadow-sm">
          <SectionTitle>Create New Notification</SectionTitle>
          <div className="row g-3 mb-3">
            <div className="col-md-6 col-12">
              <Label>Recipient Type</Label>
              <Select className="form-select">
                <option>All Users</option>
                <option>Drivers Only</option>
                <option>Staff Only</option>
              </Select>
            </div>
            <div className="col-md-6 col-12">
              <Label>Notification Type</Label>
              <Select className="form-select">
                <option>Push Notification</option>
                <option>Email</option>
              </Select>
            </div>
          </div>
          <div className="mb-3">
            <Label>Title</Label>
            <Input
              className="form-control"
              placeholder="Enter notification title"
            />
          </div>
          <div className="mb-3">
            <Label>Message</Label>
            <TextArea
              className="form-control"
              rows="3"
              placeholder="Enter notification message"
            />
          </div>
          <div className="d-flex justify-content-end">
            <SendButton className="btn">Send Notification</SendButton>
          </div>
        </Card>

        {/* Notification History */}
        <Card className="p-4 shadow-sm">
          <SectionTitle>Notification History</SectionTitle>
          <FilterBar className="d-flex justify-content-end align-items-center flex-wrap mb-3 gap-2">
            <span className="text-danger fw-bold">●</span>
            <button className="btn btn-outline-secondary btn-sm">Filter</button>
            <button className="btn btn-outline-secondary btn-sm">Export</button>
          </FilterBar>

          {notificationData.map((item, index) => (
            <NotificationItem key={index}>
              <div className="d-flex justify-content-between align-items-start flex-wrap gap-2">
                <div className="flex-grow-1">
                  <ItemTitle>{item.title}</ItemTitle>
                  <ItemMessage>{item.message}</ItemMessage>
                  <ItemMeta>{item.meta}</ItemMeta>
                </div>
                <div className="d-flex align-items-start flex-shrink-0">
                  <Badge status={item.status}>{item.status}</Badge>
                  <FaEllipsisV className="text-muted ms-2 mt-1" />
                </div>
              </div>
            </NotificationItem>
          ))}

          <Pagination className="d-flex justify-content-between align-items-center flex-wrap gap-2 mt-3">
            <span>Showing 1–3 of 24 notifications</span>
            <div className="btn-group">
              <button className="btn btn-outline-secondary btn-sm">
                Previous
              </button>
              <button className="btn btn-primary btn-sm">1</button>
              <button className="btn btn-outline-secondary btn-sm">2</button>
              <button className="btn btn-outline-secondary btn-sm">3</button>
              <button className="btn btn-outline-secondary btn-sm">Next</button>
            </div>
          </Pagination>
        </Card>
      </div>
    </Wrapper>
  );
};

export default NotificationPanel;

// Styled Components
const Wrapper = styled.div`
  width: 100%;
`;

const Header = styled.div``;
const UserDropdown = styled.div`
  cursor: pointer;
`;
const UserName = styled.span`
  font-weight: 500;
`;

const Card = styled.div`
  background: #fff;
  border-radius: 8px;
`;

const SectionTitle = styled.h6`
  font-weight: 600;
  margin-bottom: 15px;
`;

const Label = styled.label`
  font-weight: 500;
  font-size: 14px;
`;

const Select = styled.select``;

const Input = styled.input``;

const TextArea = styled.textarea``;

const SendButton = styled.button`
  background-color: #007bff;
  color: white;
`;

const FilterBar = styled.div``;

const NotificationItem = styled.div`
  border-bottom: 1px solid #e9ecef;
  padding: 12px 0;
`;

const ItemTitle = styled.h6`
  font-weight: 600;
`;

const ItemMessage = styled.p`
  margin: 5px 0;
  color: #495057;
`;

const ItemMeta = styled.span`
  font-size: 12px;
  color: #868e96;
`;

const Badge = styled.span`
  background-color: ${(props) =>
    props.status === "Sent" ? "#28a745" : "#ffc107"};
  color: white;
  padding: 2px 8px;
  border-radius: 12px;
  font-size: 12px;
`;

const Pagination = styled.div``;

const notificationData = [
  {
    title: "New Feature Released",
    message: "We just launched the cab booking feature.",
    meta: "Today at 10:00 AM",
    status: "Sent",
  },
  {
    title: "Maintenance Downtime",
    message: "Scheduled maintenance on 20th May.",
    meta: "Yesterday at 8:00 PM",
    status: "Pending",
  },
  {
    title: "Driver Update",
    message: "Please update your app to continue using services.",
    meta: "2 days ago",
    status: "Sent",
  },
];
