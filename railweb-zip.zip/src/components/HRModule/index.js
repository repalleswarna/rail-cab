import React from "react";
import styled, { createGlobalStyle } from "styled-components";
import "bootstrap/dist/css/bootstrap.min.css";
import {
  FaUsers,
  FaUserCheck,
  FaUserClock,
  FaClock,
  FaBell,
  FaEllipsisV,
  FaCheck,
  FaTimes,
} from "react-icons/fa";
import { Button } from "react-bootstrap";
import { MdOutlineKeyboardArrowDown } from "react-icons/md";

/* ───────────────────────────────
   GLOBAL STYLE → hides scrollbars
   ─────────────────────────────── */
const GlobalStyle = createGlobalStyle`
  /* Chrome, Safari, Opera */
  body::-webkit-scrollbar { display: none; }
  /* Firefox */
  body { scrollbar-width: none; }
  /* IE & Edge */
  body { -ms-overflow-style: none; }
`;

/* ───────────────────────────────
   STYLED COMPONENTS
   ─────────────────────────────── */
const HeaderContainer = styled.div`
  position: fixed;
  top: 0;
  left: 250px; /* Added this to account for sidebar width */
  right: 0;
  background: white;
  border-radius: 0 0 9px 9px;
  padding: 1rem 1.5rem;
  box-shadow: 0 2px 6px rgba(0, 0, 0, 0.1);
  border: 1px solid #ddd;
  z-index: 1000;
  /* Removed width: 100% as it's not needed with left/right positioning */
`;
const Container = styled.div`
  padding: 5rem 1rem 1rem;
  background-color: #f5f7fa;
  font-family: "Segoe UI", Tahoma, Geneva, Verdana, sans-serif;
  min-height: 100vh;
  /* Added this to push content right of sidebar */
  width: calc(100% - 250px); /* Added this to account for sidebar width */

  @media (min-width: 768px) {
    padding: 5rem 1.5rem 1.5rem;
  }
`;

const Header = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
`;

const StatBox = styled.div`
  background: white;
  border-radius: 3px;
  padding: 2rem;
  margin-bottom: 1rem;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.05);
  display: flex;
  justify-content: space-between;
  align-items: center;

  h6 {
    font-size: 0.8rem;
    color: #6c757d;
    font-weight: 500;
  }
  h5 {
    font-size: 1.3rem;
    font-weight: 600;
    margin: 0;
    color: #2c3e50;
  }
  .text-content {
    text-align: left;
  }
  .icon {
    padding: 0.5rem;
    border-radius: 50%;
    width: 36px;
    height: 36px;
    display: flex;
    justify-content: center;
    align-items: center;
  }
`;

const Section = styled.div`
  background: white;
  border-radius: 10px;
  padding: 1rem;
  margin-bottom: 1rem;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.05);
`;

const Avatar = styled.img`
  width: 36px;
  height: 36px;
  border-radius: 50%;
  object-fit: cover;
  margin-right: 10px;
`;

const EmployeeCard = styled.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 0.6rem 0;
  border-bottom: 1px solid #f0f0f0;

  &:last-child {
    border-bottom: none;
  }
`;

const LeaveRequestCard = styled.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 0.6rem 0;
  border-bottom: 1px solid #f0f0f0;
`;

const MemoCard = styled.div`
  background: white;
  border-radius: 8px;
  padding: 0.8rem;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.05);
  margin-top: 1rem;
  width: 100%;
  max-width: 380px;
  border: 1px solid #ddd;
`;

const AttendanceBox = styled.div`
  padding: 0.8rem;
  border-radius: 8px;
  width: 48%;
  text-align: center;
  font-weight: 600;
`;

const AttendancePresent = styled(AttendanceBox)`
  background-color: #e6f7ee;
  color: #28a745;
`;

const AttendanceAbsent = styled(AttendanceBox)`
  background-color: #fce8e6;
  color: #dc3545;
`;

/* ───────────────────────────────
   COMPONENT
   ─────────────────────────────── */
const HRModule = () => (
  <>
    <GlobalStyle />
    <Container className="container-fluid">
      <HeaderContainer>
        <Header>
          <h4
            style={{ fontWeight: "600", color: "#2c3e50", fontSize: "1.2rem" }}
          >
            HR Module
          </h4>
          <div className="d-flex align-items-center gap-3">
            <FaBell size={16} color="#6c757d" />
            <div className="d-flex align-items-center">
              <Avatar
                src="https://randomuser.me/api/portraits/women/44.jpg"
                alt="Sarah Wilson"
              />
              <span style={{ fontWeight: "500", fontSize: "0.9rem" }}>
                Sarah Wilson <MdOutlineKeyboardArrowDown size={20} />
              </span>
            </div>
          </div>
        </Header>
      </HeaderContainer>

      <div className="row mb-4 ">
        <div className="col-6 col-md-3 mb-3">
          <StatBox>
            <div className="text-content">
              <h6>Total Employees</h6>
              <h5>156</h5>
            </div>
            <div className="icon" style={{ backgroundColor: "#d0e7ff" }}>
              <FaUsers size={18} color="#007bff" />
            </div>
          </StatBox>
        </div>
        <div className="col-6 col-md-3 mb-3">
          <StatBox>
            <div className="text-content">
              <h6>Present Today</h6>
              <h5>142</h5>
            </div>
            <div className="icon" style={{ backgroundColor: "#c2f0d3" }}>
              <FaUserCheck size={18} color="#28a745" />
            </div>
          </StatBox>
        </div>
        <div className="col-6 col-md-3 mb-3">
          <StatBox>
            <div className="text-content">
              <h6>On Leave</h6>
              <h5>14</h5>
            </div>
            <div className="icon" style={{ backgroundColor: "#ffe2b2" }}>
              <FaUserClock size={18} color="#ff9900" />
            </div>
          </StatBox>
        </div>
        <div className="col-6 col-md-3 mb-3">
          <StatBox>
            <div className="text-content">
              <h6>Pending Requests</h6>
              <h5>8</h5>
            </div>
            <div className="icon" style={{ backgroundColor: "#e2d6ff" }}>
              <FaClock size={18} color="#6f42c1" />
            </div>
          </StatBox>
        </div>
      </div>

      <div className="row">
        <div className="col-md-6 mb-3">
          <Section>
            <div className="d-flex justify-content-between align-items-center mb-3">
              <h5
                style={{
                  fontSize: "0.95rem",
                  fontWeight: "600",
                  color: "#2c3e50",
                }}
              >
                Employee Management
              </h5>
              <Button
                variant="primary"
                size="sm"
                style={{
                  backgroundColor: "#4e73df",
                  border: "none",
                  fontSize: "0.8rem",
                  padding: "0.25rem 0.5rem",
                }}
              >
                + Add Employee
              </Button>
            </div>
            <hr />

            <div style={{ marginBottom: "8rem" }}>
              <div className="d-flex justify-content-between align-items-center mb-2">
                <span style={{ fontSize: "0.8rem", color: "#6c757d" }}>
                  Employee
                </span>
                <span style={{ fontSize: "0.8rem", color: "#6c757d" }}>
                  Role
                </span>
                <span style={{ fontSize: "0.8rem", color: "#6c757d" }}>
                  Status
                </span>
                <span style={{ fontSize: "0.8rem", color: "#6c757d" }}>
                  Actions
                </span>
              </div>

              <EmployeeCard>
                <div
                  className="d-flex align-items-center"
                  style={{ width: "40%" }}
                >
                  <Avatar
                    src="https://randomuser.me/api/portraits/men/46.jpg"
                    alt="Alex Johnson"
                  />
                  <div>
                    <div style={{ fontWeight: "600", fontSize: "0.85rem" }}>
                      Alex Johnson
                    </div>
                    <div style={{ fontSize: "0.7rem", color: "#6c757d" }}>
                      alex.j@ralicab.com
                    </div>
                  </div>
                </div>
                <div style={{ width: "20%", fontSize: "0.8rem" }}>
                  Service Manager
                </div>
                <div style={{ width: "20%" }}>
                  <span
                    className="badge rounded-pill"
                    style={{
                      backgroundColor: "#e6f7ee",
                      color: "#28a745",
                      padding: "0.2rem 0.4rem",
                      fontWeight: "500",
                      fontSize: "0.75rem",
                    }}
                  >
                    Active
                  </span>
                </div>
                <div style={{ width: "20%", textAlign: "right" }}>
                  <FaEllipsisV size={14} color="#6c757d" />
                </div>
              </EmployeeCard>
            </div>
          </Section>
        </div>

        <div className="col-md-6 mb-3">
          <Section style={{ marginBottom: "1rem" }}>
            <h5
              style={{
                fontSize: "0.95rem",
                fontWeight: "600",
                color: "#2c3e50",
              }}
            >
              Today's Attendance
            </h5>
            <hr />
            <div className="d-flex justify-content-between">
              <AttendancePresent>
                Present
                <br />
                <span style={{ fontSize: "1.1rem" }}>91%</span>
              </AttendancePresent>
              <AttendanceAbsent>
                Absent
                <br />
                <span style={{ fontSize: "1.1rem" }}>9%</span>
              </AttendanceAbsent>
            </div>
          </Section>

          <Section>
            <h5
              style={{
                fontSize: "0.95rem",
                fontWeight: "600",
                color: "#2c3e50",
              }}
            >
              Leave Requests
            </h5>
            <hr />
            <div>
              <LeaveRequestCard>
                <div
                  className="d-flex align-items-center"
                  style={{ width: "70%" }}
                >
                  <Avatar
                    src="https://randomuser.me/api/portraits/women/68.jpg"
                    alt="Emma Wilson"
                  />
                  <div>
                    <div style={{ fontWeight: "600", fontSize: "0.85rem" }}>
                      Emma Wilson
                    </div>
                    <div style={{ fontSize: "0.7rem", color: "#6c757d" }}>
                      Sick Leave - 2 days
                    </div>
                  </div>
                </div>
                <div
                  className="d-flex gap-2"
                  style={{ width: "30%", justifyContent: "flex-end" }}
                >
                  <Button
                    size="sm"
                    variant="success"
                    style={{
                      padding: "0.2rem 0.4rem",
                      fontSize: "0.7rem",
                      display: "flex",
                      alignItems: "center",
                    }}
                  >
                    <FaCheck className="me-1" size={10} /> Approve
                  </Button>
                  <Button
                    size="sm"
                    variant="danger"
                    style={{
                      padding: "0.2rem 0.4rem",
                      fontSize: "0.7rem",
                      display: "flex",
                      alignItems: "center",
                    }}
                  >
                    <FaTimes className="me-1" size={10} /> Reject
                  </Button>
                </div>
              </LeaveRequestCard>
            </div>
          </Section>
        </div>
      </div>

      <Section>
        <div className="d-flex justify-content-between align-items-center">
          <h6 style={{ fontSize: "0.95rem" }}>Internal Memos</h6>
          <Button
            variant="primary"
            size="sm"
            style={{
              fontSize: "0.8rem",
              padding: "0.25rem 0.5rem",
            }}
          >
            + New Memo
          </Button>
        </div>
        <hr />
        <MemoCard>
          <div className="d-flex justify-content-between align-items-center">
            <h6 className="mb-0" style={{ fontSize: "0.9rem" }}>
              Monthly Team Meeting
            </h6>
            <small className="text-muted" style={{ fontSize: "0.7rem" }}>
              2 hours ago
            </small>
          </div>
          <p className="mt-2 mb-1" style={{ fontSize: "0.8rem" }}>
            Monthly team meeting scheduled for March 15th, 2025 at 10:00 AM in
            the main conference room.
          </p>
          <span className="text-primary" style={{ fontSize: "0.75rem" }}>
            High Priority
          </span>
        </MemoCard>
      </Section>
    </Container>
  </>
);

export default HRModule;
