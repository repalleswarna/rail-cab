import React, { useState } from "react";
import styled from "styled-components";
import "bootstrap/dist/css/bootstrap.min.css";
import { IoIosNotifications } from "react-icons/io";
import { FaAngleDown } from "react-icons/fa6";
import {
  FaSearch,
  FaTrain,
  FaMapMarkerAlt,
  FaCarSide,
  FaBoxes,
  FaHandshake,
  FaIdBadge,
  FaCalendarAlt,
  FaEdit,
  FaTrash,
} from "react-icons/fa";
import {
  Container,
  Row,
  Col,
  Nav,
  Button,
  Form,
  Table,
  Badge,
  Pagination,
  InputGroup,
  Modal,
} from "react-bootstrap";
import PickupDropPoints from "../PickupDropPoints";
import CabCategories from "../CabCategories";
import CabInventory from "../CabInventory";
import Vendors from "../Vendors";
import Drivers from "../Drivers";
import TrainSchedule from "../TrainSchedule";

const ServiceManagerContainer = styled.div`
  background-color: #f8f9fa;
  min-height: 100vh;
  width: 100%;
  transition: filter 0.3s ease;
  filter: ${({ blur }) => (blur ? "blur(5px)" : "none")};
`;

const ContentContainer = styled.div`
  max-width: 1500px;
  margin: 0 auto;
  padding: 20px;
`;

const Header = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 1rem;
  border-bottom: 1px solid #dee2e6;
  background-color: #fff;
  flex-wrap: wrap;
`;

const Title = styled.h4`
  margin-bottom: 0;
  font-weight: 600;
  font-size: 30px;
  flex: 1 1 auto;
  min-width: 200px;
`;

const ProfileWrapper = styled.div`
  display: flex;
  align-items: center;
  gap: 1rem;
  flex-wrap: nowrap;
`;

const ProfileDetails = styled.div`
  display: flex;
  align-items: center;
  gap: 0.5rem;
  white-space: nowrap;
`;

const ProfileImage = styled.img`
  width: 35px;
  height: 35px;
  border-radius: 50%;
`;

const MainBox = styled.div`
  background-color: #fff;
  padding: 1.5rem;
  border-radius: 0.5rem;
  box-shadow: 0 0.125rem 0.25rem rgba(0, 0, 0, 0.075);
`;

const ModalOverlay = styled.div`
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background-color: rgba(0, 0, 0, 0.5);
  display: flex;
  justify-content: center;
  align-items: center;
  z-index: 1050;
`;

const ModalContainer = styled.div`
  background: #fff;
  padding: 2rem;
  border-radius: 10px;
  max-width: 800px;
  width: 90%;
  max-height: 90vh;
  overflow-y: auto;
  box-shadow: 0 0 20px rgba(0, 0, 0, 0.2);
`;

const ModalHeader = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 1.5rem;
  padding-bottom: 1rem;
  border-bottom: 1px solid #dee2e6;
`;

const ModalTitle = styled.h5`
  margin: 0;
  font-weight: 600;
  font-size: 1.5rem;
`;

const ModalBody = styled.div`
  margin-bottom: 1.5rem;
`;

const ModalFooter = styled.div`
  display: flex;
  justify-content: flex-end;
  gap: 0.5rem;
  padding-top: 1rem;
  border-top: 1px solid #dee2e6;
`;

const CloseButton = styled.button`
  background: none;
  border: none;
  font-size: 1.5rem;
  cursor: pointer;
  color: #6c757d;
  &:hover {
    color: #495057;
  }
`;

const RedAsterisk = styled.span`
  color: red;
`;

const BluePlusButton = styled.button`
  color: blue !important;
  border-color: #6c757d;
  background-color: transparent;
`;

function AddStationModal({ show, handleClose }) {
  const [formData, setFormData] = useState({
    stationName: "",
    city: "",
    pickupPoint: "",
    locationDetails: "",
    category: "",
    platforms: "",
    openingTime: "",
    closingTime: "",
    contactNumber: "",
    manager: "",
    isActive: true,
    notes: "",
  });

  const [errors, setErrors] = useState({});

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: type === "checkbox" ? checked : value,
    }));

    // Clear error as user types
    setErrors((prev) => ({ ...prev, [name]: "" }));
  };

  const validate = () => {
    const newErrors = {};
    const requiredFields = [
      "stationName",
      "city",
      "pickupPoint",
      "locationDetails",
      "category",
      "platforms",
      "openingTime",
      "closingTime",
      "contactNumber",
      "manager",
    ];

    requiredFields.forEach((field) => {
      if (!formData[field]) {
        newErrors[field] = "Required";
      }
    });

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSave = (e) => {
    e.preventDefault();
    if (validate()) {
      alert("Station saved successfully!");
      handleClose();
    }
  };

  if (!show) return null;

  return (
    <ModalOverlay>
      <ModalContainer>
        <ModalHeader>
          <ModalTitle>Add New Station</ModalTitle>
          <CloseButton onClick={handleClose}>&times;</CloseButton>
        </ModalHeader>
        <ModalBody>
          <Form onSubmit={handleSave}>
            <div className="row g-3">
              <div className="col-md-6">
                <Form.Group>
                  <Form.Label>
                    Station Name <RedAsterisk>*</RedAsterisk>
                  </Form.Label>
                  <Form.Control
                    type="text"
                    name="stationName"
                    value={formData.stationName}
                    onChange={handleChange}
                    placeholder="Enter Station Name"
                    className={errors.stationName ? "is-invalid" : ""}
                  />
                </Form.Group>
              </div>

              <div className="col-md-6">
                <Form.Group>
                  <Form.Label>
                    City <RedAsterisk>*</RedAsterisk>
                  </Form.Label>
                  <Form.Select
                    name="city"
                    value={formData.city}
                    onChange={handleChange}
                    className={errors.city ? "is-invalid" : ""}
                  >
                    <option value="">Select City</option>
                    <option value="City A">City A</option>
                  </Form.Select>
                </Form.Group>
              </div>

              <div className="col-md-6">
                <Form.Group>
                  <Form.Label>
                    Pickup Points <RedAsterisk>*</RedAsterisk>
                  </Form.Label>
                  <Form.Control
                    type="text"
                    name="pickupPoint"
                    value={formData.pickupPoint}
                    onChange={handleChange}
                    placeholder="Point Name"
                    className={errors.pickupPoint ? "is-invalid" : ""}
                  />
                </Form.Group>
              </div>

              <div className="col-md-5">
                <Form.Group>
                  <Form.Label>&nbsp;</Form.Label>
                  <Form.Control
                    type="text"
                    name="locationDetails"
                    value={formData.locationDetails}
                    onChange={handleChange}
                    placeholder="Location Details"
                    className={errors.locationDetails ? "is-invalid" : ""}
                  />
                </Form.Group>
              </div>

              <div className="col-md-1 d-flex align-items-end">
                <BluePlusButton
                  type="button"
                  className="btn btn-outline-secondary w-100"
                >
                  +
                </BluePlusButton>
              </div>

              <div className="col-md-6">
                <Form.Group>
                  <Form.Label>
                    Station Category <RedAsterisk>*</RedAsterisk>
                  </Form.Label>
                  <Form.Select
                    name="category"
                    value={formData.category}
                    onChange={handleChange}
                    className={errors.category ? "is-invalid" : ""}
                  >
                    <option value="">Select Category</option>
                    <option value="Category A">Category A</option>
                  </Form.Select>
                </Form.Group>
              </div>

              <div className="col-md-6">
                <Form.Group>
                  <Form.Label>
                    Number of Platforms <RedAsterisk>*</RedAsterisk>
                  </Form.Label>
                  <Form.Control
                    type="number"
                    name="platforms"
                    value={formData.platforms}
                    onChange={handleChange}
                    placeholder="Enter number"
                    className={errors.platforms ? "is-invalid" : ""}
                  />
                </Form.Group>
              </div>

              <div className="col-md-6">
                <Form.Group>
                  <Form.Label>
                    Opening Time <RedAsterisk>*</RedAsterisk>
                  </Form.Label>
                  <Form.Control
                    type="time"
                    name="openingTime"
                    value={formData.openingTime}
                    onChange={handleChange}
                    className={errors.openingTime ? "is-invalid" : ""}
                  />
                </Form.Group>
              </div>

              <div className="col-md-6">
                <Form.Group>
                  <Form.Label>
                    Closing Time <RedAsterisk>*</RedAsterisk>
                  </Form.Label>
                  <Form.Control
                    type="time"
                    name="closingTime"
                    value={formData.closingTime}
                    onChange={handleChange}
                    className={errors.closingTime ? "is-invalid" : ""}
                  />
                </Form.Group>
              </div>

              <div className="col-md-6">
                <Form.Group>
                  <Form.Label>
                    Station Contact Number <RedAsterisk>*</RedAsterisk>
                  </Form.Label>
                  <Form.Control
                    type="text"
                    name="contactNumber"
                    value={formData.contactNumber}
                    onChange={handleChange}
                    placeholder="Enter number"
                    className={errors.contactNumber ? "is-invalid" : ""}
                  />
                </Form.Group>
              </div>

              <div className="col-md-6">
                <Form.Group>
                  <Form.Label>
                    Station Manager <RedAsterisk>*</RedAsterisk>
                  </Form.Label>
                  <Form.Control
                    type="text"
                    name="manager"
                    value={formData.manager}
                    onChange={handleChange}
                    placeholder="Manager Name"
                    className={errors.manager ? "is-invalid" : ""}
                  />
                </Form.Group>
              </div>

              <div className="col-md-12">
                <div className="form-check form-switch">
                  <input
                    className="form-check-input"
                    type="checkbox"
                    role="switch"
                    id="activeToggle"
                    name="isActive"
                    checked={formData.isActive}
                    onChange={handleChange}
                  />
                  <label className="form-check-label" htmlFor="activeToggle">
                    Station Active
                  </label>
                </div>
              </div>

              <div className="col-md-12">
                <Form.Group>
                  <Form.Label>Additional Notes</Form.Label>
                  <Form.Control
                    as="textarea"
                    rows={3}
                    name="notes"
                    value={formData.notes}
                    onChange={handleChange}
                  />
                </Form.Group>
              </div>
            </div>
          </Form>
        </ModalBody>
        <ModalFooter>
          <Button variant="light" onClick={handleClose}>
            Cancel
          </Button>
          <Button variant="primary" onClick={handleSave}>
            Save Station
          </Button>
        </ModalFooter>
      </ModalContainer>
    </ModalOverlay>
  );
}

function StationsManagement() {
  const [currentPage, setCurrentPage] = useState(1);
  const [showAddStationModal, setShowAddStationModal] = useState(false);

  const handlePageClick = (page) => {
    setCurrentPage(page);
  };

  return (
    <>
      <MainBox>
        <div
          style={{
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            marginBottom: "1.5rem",
            flexWrap: "wrap",
            gap: "1rem",
          }}
        >
          <h5 style={{ marginBottom: 0 }}>Stations Management</h5>
          <Button
            variant="primary"
            className="mt-2 mt-sm-0"
            onClick={() => setShowAddStationModal(true)}
          >
            + Add Station
          </Button>
        </div>

        {/* Filters */}
        <Row className="g-3 mb-4">
          <Col xs={12} md={6}>
            <InputGroup>
              <InputGroup.Text>
                <FaSearch />
              </InputGroup.Text>
              <Form.Control placeholder="Search stations..." />
            </InputGroup>
          </Col>
          <Col xs={6} md={3}>
            <Form.Select>
              <option>All Cities</option>
            </Form.Select>
          </Col>
          <Col xs={6} md={3}>
            <Form.Select>
              <option>Status: All</option>
            </Form.Select>
          </Col>
        </Row>

        {/* Table */}
        <Table responsive className="align-middle">
          <thead>
            <tr>
              <th>Station Name</th>
              <th className="d-none d-sm-table-cell">City</th>
              <th className="d-none d-md-table-cell">Pickup Points</th>
              <th className="d-none d-md-table-cell">Status</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>
                <div className="d-flex flex-column flex-sm-row align-items-start align-items-sm-center">
                  <FaTrain className="me-2 text-secondary" />
                  <span>Mumbai Central</span>
                </div>
              </td>
              <td className="d-none d-sm-table-cell">Mumbai</td>
              <td className="d-none d-md-table-cell">12 points</td>
              <td className="d-none d-md-table-cell">
                <Badge bg="success" pill>
                  Active
                </Badge>
              </td>
              <td>
                <div className="d-flex gap-2 flex-wrap">
                  <Button
                    variant="link"
                    className="text-primary p-0"
                    aria-label="Edit"
                  >
                    <FaEdit />
                  </Button>
                  <Button
                    variant="link"
                    className="text-danger p-0"
                    aria-label="Delete"
                  >
                    <FaTrash />
                  </Button>
                </div>
              </td>
            </tr>
          </tbody>
        </Table>

        {/* Pagination */}
        <div
          style={{
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            marginTop: "1rem",
            flexWrap: "wrap",
            gap: "0.75rem",
          }}
        >
          <div>Showing 1 to 10 of 45 entries</div>
          <div
            className="pagination-scroll"
            style={{
              overflowX: "auto",
              whiteSpace: "nowrap",
              maxWidth: "100%",
            }}
          >
            <Pagination className="mb-0">
              <Pagination.Prev
                onClick={() =>
                  setCurrentPage((prev) => (prev > 1 ? prev - 1 : prev))
                }
              >
                Previous
              </Pagination.Prev>
              {[1, 2, 3].map((page) => (
                <Pagination.Item
                  key={page}
                  active={currentPage === page}
                  onClick={() => handlePageClick(page)}
                  style={{
                    backgroundColor:
                      currentPage === page ? "#0d6efd" : "transparent",
                    borderColor: "#dee2e6",
                    color: currentPage === page ? "#fff" : "#000",
                  }}
                >
                  {page}
                </Pagination.Item>
              ))}
              <Pagination.Next
                onClick={() =>
                  setCurrentPage((prev) => (prev < 3 ? prev + 1 : prev))
                }
              >
                Next
              </Pagination.Next>
            </Pagination>
          </div>
        </div>
      </MainBox>

      {/* Add Station Modal */}
      <AddStationModal
        show={showAddStationModal}
        handleClose={() => setShowAddStationModal(false)}
      />
    </>
  );
}

function ServiceManager() {
  const [activeTab, setActiveTab] = useState("stations");
  const [blurBackground, setBlurBackground] = useState(false);

  const renderActiveTab = () => {
    switch (activeTab) {
      case "stations":
        return <StationsManagement />;
      case "pickup":
        return <PickupDropPoints />;
      case "cab":
        return <CabCategories />;
      case "inventory":
        return <CabInventory />;
      case "vendors":
        return <Vendors />;
      case "drivers":
        return <Drivers />;
      case "schedule":
        return <TrainSchedule />;
      default:
        return <StationsManagement />;
    }
  };

  return (
    <ServiceManagerContainer blur={blurBackground}>
      <ContentContainer>
        {/* Header */}
        <Header>
          <Title>Service Manager</Title>
          <ProfileWrapper>
            <IoIosNotifications size={24} />
            <ProfileImage
              src="https://randomuser.me/api/portraits/men/32.jpg"
              alt="John Smith"
            />
            <ProfileDetails>
              <i className="bi bi-caret-down-fill text-secondary"></i>
              <span className="font-size-60px font-weight-300">
                John Smith <FaAngleDown />
              </span>
            </ProfileDetails>
          </ProfileWrapper>
        </Header>

        {/* Navigation Tabs */}
        <Nav variant="tabs" className="bg-white px-3 flex-wrap">
          {[
            { key: "stations", label: "Stations", icon: <FaTrain /> },
            { key: "pickup", label: "Pickup Points", icon: <FaMapMarkerAlt /> },
            { key: "cab", label: "Cab Categories", icon: <FaCarSide /> },
            { key: "inventory", label: "Inventory", icon: <FaBoxes /> },
            { key: "vendors", label: "Vendors", icon: <FaHandshake /> },
            { key: "drivers", label: "Drivers", icon: <FaIdBadge /> },
            {
              key: "schedule",
              label: "Train Schedule",
              icon: <FaCalendarAlt />,
            },
          ].map((item) => (
            <Nav.Item key={item.key}>
              <Nav.Link
                eventKey={item.key}
                active={activeTab === item.key}
                onClick={() => setActiveTab(item.key)}
                style={{ color: activeTab === item.key ? "#0d6efd" : "#000" }}
              >
                {item.icon}
                <span className="ms-2">{item.label}</span>
              </Nav.Link>
            </Nav.Item>
          ))}
        </Nav>

        {/* Main Content */}
        <Container fluid className="p-4">
          {React.cloneElement(renderActiveTab(), {
            setBlurBackground: setBlurBackground,
          })}
        </Container>
      </ContentContainer>
    </ServiceManagerContainer>
  );
}

export default ServiceManager;
