import Dashboard from "./components/Dashboard";
import "./App.css";
import "bootstrap/dist/css/bootstrap.min.css";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import NotificationPanel from "./components/NotificationPanel";
import SettingsPanel from "./components/SettingsPanel";
import ServiceManager from "./components/ServiceManager";
import CabCategories from "./components/CabCategories";
import PickupDropPoints from "./components/PickupDropPoints";
import SideBar from "./components/SideBar";
import Accountant from "./components/Accountant";
import SupportPortal from "./components/SupportPortal";
import HRModule from "./components/HRModule";
import ContentManagement from "./components/ContentManagement";
import CabInventory from "./components/CabInventory";
import Vendors from "./components/Vendors";
import Drivers from "./components/Drivers";
import TrainSchedule from "./components/TrainSchedule";
import SupportTickets from "./components/SupportTickets";

const App = () => {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<SideBar />} />
        <Route path="/notification" element={<NotificationPanel />} />
        <Route path="/settingspanel" element={<SettingsPanel />} />
        <Route path="/service-manager" element={<ServiceManager />} />
        <Route path="/cab-categories" element={<CabCategories />} />
        <Route path="/pickup-drop" element={<PickupDropPoints />} />
        <Route path="/sidebar" element={<SideBar />} />
        <Route path="/accountant" element={<Accountant />} />
        <Route path="/support-portal" element={<SupportPortal />} />
        <Route path="/hr-module" element={<HRModule />} />
        <Route path="/content-management" element={<ContentManagement />} />
        <Route path="/inventory" element={<CabInventory />} />
        <Route path="/vendor" element={<Vendors />} />
        <Route path="/driver" element={<Drivers />} />
        <Route path="/train-schedule" element={<TrainSchedule />} />
        <Route path="/support-tickets" element={<SupportTickets />} />
      </Routes>
    </BrowserRouter>
  );
};

export default App;
